#ifndef __timer3_H
#define __timer3_H
#include "sys.h"


void tim3_init(u16 arr,u16 psc);

#endif

